'use strict';

 const functions = require('firebase-functions');
 const {google} = require('googleapis');
 const {WebhookClient} = require('dialogflow-fulfillment');
 //const BIGQUERY = require('@google-cloud/bigquery');
 
 const nodemailer = require("nodemailer");
 const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'abc@xyz.com', //enter your email-id here
        pass: 'password'         //enter corresponding password
    }
});

// Enter your calendar ID below and service account JSON below
const calendarId = "hutp4mc6rm4vtjlllhfsnmpjf4@group.calendar.google.com";
const serviceAccount = {
  "type": "service_account",
  "project_id": "docreceptionist-hktcdj",
  "private_key_id": "746bbb8193004346ccb70cb8a789f93415eab724",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCi0SFEKcCzx9Ie\nnN3PBCWm7uSx8HmvKDWcmcUVw+be1FXFJujQtGh8eeJ+fECiB72KhaiMtjO1iVqA\ng29SMmZfyoIKXsnPEmqkWZEG4T0cczXds8MV87rB5ExWbDimt84Hdh6yPMTQjkkV\nL5zlGNh7rYLHTb3J7ZHW7oyvrBZf/9rKcvdOkba9YY9W3bMHa8ASrAA50B262Yrp\ngadpZi8RE9xvdKOooKb+EzmzqjMqOY6AR/MiG0N5ybIFa040LVHGm9pAWCMn/yC3\nx1apjMXXJ4xD55OGqkKK3PEZjh6Zg3hirxPP0DzLmCXfRbulAJ+H3pgCVeRg6RjN\nZmQw9+xVAgMBAAECggEADxPYxcwsCToG7kjOjZ4vsm7LBONlEWBi3paq1qImnhoB\nu1koFDOwvV44KEhvX9HhrpNEEYvJ7BTFKcOCKpV6P4KsWjN+8ssczw1wTbfMBfdx\nVI+SEFVaxRvUKeipsl6xGKXKn+zauQmEIQ8gs2KCoalmw/giDDIQ4FuE8bu48rjD\n+Hdwb3i2mWnS73h3c1iF53HHAk7/eEmXmHi9hkt/txIILsDzbxR7aTOpy49zscv/\nzS40QQB73TVBC8jCTk3oq78lm2yDkMsuUvefa/MmH7/DxrQgK0PboJfy999btxXA\nOpmTugWDg6946z7adleZ99qJ3Hpsn3CqnDNa5/RXPQKBgQDW2f8JHnUNtBfy/mSa\nPUqjADZ8O30RR69XnmSvlafC6diyNuc4L38rsNo1r3QqpM3NwH8tGPSEyDXIpTox\nUmayQtbpsoDf2wnxlZOB7S8WCcpE5Asy+OQv4g8JL3R/FvFmBk3Gv8eOB42CmokM\nu9EOUfDxDWbn0VlPT9aF9E+ylwKBgQDB/+qMlWI2+NGhsLMvJ1oMU8/OpraFqu0g\nWeebyRInCSqTrxO30g2X6gIuBRYiHWn/jMlYhg/jXMmusxY9RlPj59TpW+9ZWT5H\nooVkzc4Y9xYuQbSFXKGMVY5Fu9r1akvpF6yqbWnuSGhskiZcRNf8NMSfHDwXGUW2\nz0ToLcGx8wKBgFsnYCHhTy5CM0sADXS2/lyLsZIhtx1GuajF5dfs+aEjj7GEw7K9\nzAmgXeQbDYEuLLbXrd1XUh6nxtHa8AaO/E0zOHUsK6tOBjj+Cfg8xhZmju+NhQba\nPA3orhJqlNV6yW5MzGC/aw3iPHKl1/GUGc0mjL/ovLkrw+V3bP+mOM3/AoGBAMHE\nzs46Sw4jOqdoaaDYil2zvOVoqPgbwJtGkUqN7B6nTiqSfXxmRwOMTT8P/4p1nLEO\nOvG7fdUXka532+e5/gKuRYAMPqYcuFMuplQIKCnRagsrv5ZQ7l7P+bn3J31m/YlF\nB0Z24I6LLhn7ZGtWq/CR+C4AMpjTukkc/3N0eHo3AoGBAKBP2lZPxlqhKnSf7tul\n34M3CgDEYT12Uw4aW/ESllsDg5HejMZuESZqq3U20ZmAzXFvSiU410lUtzh5+YOF\nVEt5+/NVV8YMCER/PjwZ/1fFg76A5RRJjUfE8a0VIXr5HIE6iHazEgGL0r7rsvg6\n2YSAVB/3E/lqj9XEQmAuv4T/\n-----END PRIVATE KEY-----\n",
  "client_email": "doc-appointment@docreceptionist-hktcdj.iam.gserviceaccount.com",
  "client_id": "110591044790885697854",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/doc-appointment%40docreceptionist-hktcdj.iam.gserviceaccount.com"
}; // Starts with {"type": "service_account",...

// Set up Google Calendar Service account credentials
const serviceAccountAuth = new google.auth.JWT({
 email: serviceAccount.client_email,
 key: serviceAccount.private_key,
 scopes: 'https://www.googleapis.com/auth/calendar'
});

const calendar = google.calendar('v3');
process.env.DEBUG = 'dialogflow:*'; // enables lib debugging statements

const timeZone = 'Asia/Kolkata';
const timeZoneOffset = '+5:30';

// Set the DialogflowApp object to handle the HTTPS POST request.
exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request, response) => {
 const agent = new WebhookClient({ request, response });
 console.log("Intent Name",agent.intent);
 console.log("Parameters", agent.parameters);
 function makeAppointment (agent) {
   let appointment_type = agent.parameters.AppointmentType;
   // Calculate appointment start and end datetimes (end = +1hr from start)
   let time = new Date(agent.parameters.time);
   let date = new Date(agent.parameters.date);
   let dateTimeStart = new Date(date);
   dateTimeStart.setHours(time.getHours());
   dateTimeStart.setMinutes(time.getMinutes());
   //const dateTimeStart = new Date(Date.parse(agent.parameters.date.split('T')[0] + 'T' + agent.parameters.time.split('T')[1].split('+')[0] + timeZoneOffset));   
   const dateTimeEnd = new Date(new Date(dateTimeStart).setHours(dateTimeStart.getHours() + 1));
   const appointmentTimeString = dateTimeStart.toLocaleString(
     'en-US',
     { month: 'long', day: 'numeric', hour: 'numeric', timeZone: timeZone }
   );
     // Check the availibility of the time, and make an appointment if there is time on the calendar
     return createCalendarEvent(dateTimeStart, dateTimeEnd, appointment_type).then(() => {
       agent.add(`Ok, let me see if we can fit you in. ${appointmentTimeString} is fine!.`);
       // Insert data into a table
      //addToBigQuery(agent, appointment_type);
     }).catch(() => {
       agent.add(`I'm sorry, there are no slots available for ${appointmentTimeString}.`);
     });
   }

// Handle the Dialogflow intent named 'setAppointment'.
 if(agent.intent=='makeAppointment'){
    let intentMap = new Map();
    intentMap.set('makeAppointment', makeAppointment);
    agent.handleRequest(intentMap);
 }
 else if(agent.intent=='SendEmailQuery'){
   let intentMap = new Map();
   intentMap.set('SendEmailQuery', sendEmail);
   agent.handleRequest(intentMap);
 }
});

/**
function addToBigQuery(agent, appointment_type) {
    const date_bq = agent.parameters.date.split('T')[0];
    const time_bq = agent.parameters.time.split('T')[1].split('-')[0];
  
    TODO(developer): Uncomment the following lines before running the sample.
    
    const projectId = "docreceptionist-hktcdj"; 
    const datasetId = "docreceptionist-hktcdj:Appointment_Info";
    const tableId = "docreceptionist-hktcdj:Appointment_Info.A_I";
    const bigquery = new BIGQUERY({
      projectId: projectId
    });
   const rows = [{date: date_bq, time: time_bq, type: appointment_type}];
  
   bigquery
  .dataset(datasetId)
  .table(tableId)
  .insert(rows)
  .then(() => {
    console.log(`Inserted ${rows.length} rows`);
  })
  .catch(err => {
    if (err && err.name === 'PartialFailureError') {
      if (err.errors && err.errors.length > 0) {
        console.log('Insert errors:');
        err.errors.forEach(err => console.error(err));
      }
    } else {
      console.error('ERROR:', err);
    }
  });
  agent.add(`Added ${date_bq} and ${time_bq} into the table`);
}
*/

function sendEmail(agent){
	let context = agent.getContext();
    //const emailParam=context.parameters['email.original'];
    //const nameParam=context.parameters['Name.original'];
    //const contact=context.parameters['phone_number.original'];
    const query=agent.parameters.query;
    const mailOptions = {
    	from: "Doc_Receptionist", // sender address
    	to: "deepak.sharma@bennett.edu.in", // list of receivers
    	subject: "Chatbot:Dr. Receptionist Query", // Subject line
    	text: `Hi query : '${query}`
	};
    transporter.sendMail(mailOptions, function (err, info) {
        if(err)
        {
          console.log(err);
        }
    });
    agent.add("Mail sent successfully to Doctor, Please wait for the reply");
 }

function createCalendarEvent (dateTimeStart, dateTimeEnd, appointment_type) {
   return new Promise((resolve, reject) => {
     calendar.events.list({
       auth: serviceAccountAuth, // List events for time period
       calendarId: calendarId,
       timeMin: dateTimeStart.toISOString(),
       timeMax: dateTimeEnd.toISOString()
     }, (err, calendarResponse) => {
       // Check if there is a event already on the Calendar
       if (err || calendarResponse.data.items.length > 0) {
         reject(err || new Error('Requested time conflicts with another appointment'));
       } else {
         // Create event for the requested time period
         calendar.events.insert({ auth: serviceAccountAuth,
           calendarId: calendarId,
           resource: {summary: appointment_type +' Appointment', description: appointment_type,
             start: {dateTime: dateTimeStart},
             end: {dateTime: dateTimeEnd}}
         }, (err, event) => {
           err ? reject(err) : resolve(event);
         }
         );
       }
     });
   });
 }